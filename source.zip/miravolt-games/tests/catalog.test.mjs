import test from 'node:test';
import assert from 'node:assert/strict';
import {filterGames, readSaved, toggleSaved} from '../src/js/catalog.js';

const games = [
  {id:'a',title:'Warframe',genres:['Екшен'],model:'freemium',platforms:['Windows']},
  {id:'b',title:'0 A.D.',genres:['Стратегія'],model:'free',platforms:['Windows','Linux']},
  {id:'c',title:'Xonotic',genres:['Екшен'],model:'free',platforms:['Windows','Linux']}
];

test('Пошук нечутливий до регістру й зайвих пробілів', () => {
  assert.deepEqual(filterGames(games,{query:'  WARframe  '}).map(g=>g.id), ['a']);
});
test('Пошук за жанром працює українською', () => {
  assert.deepEqual(filterGames(games,{query:'стратегія'}).map(g=>g.id), ['b']);
});
test('Поєднання фільтрів застосовує всі умови', () => {
  assert.deepEqual(filterGames(games,{genre:'Екшен',model:'free',savedOnly:true,saved:['a','c']}).map(g=>g.id),['c']);
});
test('Невідомий запит повертає порожню добірку', () => {
  assert.deepEqual(filterGames(games,{query:'невідома гра'}),[]);
});
test('Сортування за назвою не змінює вихідний каталог', () => {
  assert.deepEqual(filterGames(games,{sort:'title'}).map(g=>g.id),['b','a','c']);
  assert.equal(games[0].id,'a');
});
test('Збереження прибирає дублікати й сторонні ідентифікатори', () => {
  assert.deepEqual(readSaved('["a","a","unknown",42]',games),['a']);
});
test('Пошкоджені або неочікувані дані сховища не ламають каталог', () => {
  for(const input of ['broken','null','{}','"a"',null]) assert.deepEqual(readSaved(input,games),[]);
});
test('Повторне натискання вилучає гру з добірки', () => {
  const original=['a'];
  assert.deepEqual(toggleSaved(original,'b'),['a','b']);
  assert.deepEqual(toggleSaved(original,'a'),[]);
  assert.deepEqual(original,['a']);
});
