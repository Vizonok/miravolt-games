import http from 'node:http';
import {readFile,stat} from 'node:fs/promises';
import {resolve,extname,sep} from 'node:path';
const root=resolve(import.meta.dirname,'../dist');
const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.webp':'image/webp','.woff2':'font/woff2','.xml':'application/xml; charset=utf-8','.txt':'text/plain; charset=utf-8','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
  try {
    const url=new URL(req.url,'http://localhost');
    let path=resolve(root,`.${decodeURIComponent(url.pathname)}`);
    if(path!==root&&!path.startsWith(root+sep)){res.writeHead(403).end();return;}
    const info=await stat(path);
    if(info.isDirectory()) {
      if(!url.pathname.endsWith('/')){res.writeHead(301,{Location:`${url.pathname}/${url.search}`}).end();return;}
      path=resolve(path,'index.html');
    }
    res.writeHead(200,{'Content-Type':types[extname(path)]||'application/octet-stream','Cache-Control':'no-cache'});
    res.end(await readFile(path));
  } catch {
    res.writeHead(404,{'Content-Type':'text/html; charset=utf-8'});
    res.end(await readFile(resolve(root,'404.html')).catch(()=>Buffer.from('404')));
  }
});
server.listen(Number(process.env.PORT||4173),'127.0.0.1',()=>process.stdout.write('MiraVolt Games: http://127.0.0.1:4173/\n'));
