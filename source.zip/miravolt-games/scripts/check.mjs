import {readFile,readdir,stat} from 'node:fs/promises';
import {resolve,dirname,join} from 'node:path';
import {execFileSync} from 'node:child_process';

const root=resolve(import.meta.dirname,'..');
const dist=join(root,'dist');
const failures=[];
async function walk(path) {
  const entries=await readdir(path,{withFileTypes:true});
  return (await Promise.all(entries.map(entry=>entry.isDirectory()?walk(join(path,entry.name)):join(path,entry.name)))).flat();
}
const sources=[...await walk(join(root,'src/js')),...await walk(join(root,'scripts'))];
for(const file of sources.filter(file=>/\.(js|mjs)$/.test(file))) execFileSync(process.execPath,['--check',file]);
const files=await walk(dist);
const titles=new Set();
for(const file of files.filter(file=>file.endsWith('/index.html'))) {
  const html=await readFile(file,'utf8');
  const label=file.slice(dist.length+1);
  const title=html.match(/<title>(.*?)<\/title>/)?.[1];
  if(!title||titles.has(title)) failures.push(`${label}: title відсутній або дублюється`);
  titles.add(title);
  if((html.match(/<h1\b/g)||[]).length!==1) failures.push(`${label}: потрібно рівно один h1`);
  for(const marker of ['name="description"','rel="canonical"','property="og:image"','lang="uk"']) if(!html.includes(marker)) failures.push(`${label}: немає ${marker}`);
  for(const match of html.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)) {
    try {JSON.parse(match[1]);} catch {failures.push(`${label}: некоректний JSON-LD`);}
  }
  for(const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const value=match[1];
    if(/^(?:https?:|#|data:|mailto:)/.test(value)) continue;
    const local=value.split(/[?#]/)[0];
    if(!local) continue;
    const target=resolve(dirname(file),local);
    try {await stat(target);} catch {failures.push(`${label}: відсутній ресурс ${value}`);}
  }
}
const sitemap=await readFile(join(dist,'sitemap.xml'),'utf8');
const urls=[...sitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map(m=>m[1]);
if(urls.length!==17||new Set(urls).size!==17) failures.push('Sitemap має містити 17 унікальних сторінок');
if(urls.some(url=>/\/(saved|not-found)\//.test(url))) failures.push('Службові сторінки потрапили до sitemap');
if(process.env.SITE_URL&&urls.some(url=>!url.startsWith(process.env.SITE_URL))) failures.push('Адреси sitemap не відповідають SITE_URL');
if(failures.length) {process.stderr.write(failures.join('\n')+'\n');process.exit(1);}
process.stdout.write(`Перевірено синтаксис, ${titles.size} сторінок, локальні ресурси, метатеги та sitemap. Помилок немає.\n`);
