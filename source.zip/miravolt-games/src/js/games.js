export const checkedAt = '2026-11-10';
export const games = [
  {
    id:'warframe',title:'Warframe',model:'freemium',genres:['Екшен','Рольова гра'],platforms:['Windows'],developer:'Digital Extremes',
    description:'Кооперативний екшен у науково-фантастичному світі. Обирай варфрейм, збирай спорядження та вирушай на місії сам або з друзями.',
    details:'Динамічні бої, акробатичні переміщення та розвиток персонажа поєднуються з дослідженням міжпланетної системи. Різні варфрейми мають власні здібності, тож стиль проходження можна змінювати разом зі спорядженням.',
    payment:'Основна гра безкоштовна. Усередині є платна валюта, косметичні предмети та набори.',
    source:'https://www.warframe.com/',store:'https://store.steampowered.com/app/230410/Warframe/',storeName:'Steam',modes:'Один гравець, кооператив',featured:true
  },
  {
    id:'rocket-league',title:'Rocket League',model:'freemium',genres:['Спорт','Перегони'],platforms:['Windows'],developer:'Psyonix',
    description:'Футбол, у якому замість гравців — ракетні автомобілі. Виходь на арену, відпрацьовуй удари й збирай свою команду.',
    details:'Матчі поєднують керування автомобілем і фізику м’яча. Можна грати з друзями, змагатися в мережевих режимах і тренувати маневри перед наступним виходом на поле.',
    payment:'Основна гра безкоштовна. Косметичні предмети, кредити та преміальний Rocket Pass можуть коштувати грошей.',
    source:'https://www.rocketleague.com/',store:'https://store.epicgames.com/p/rocket-league',storeName:'Epic Games Store',modes:'Один гравець, мережеві матчі',featured:true
  },
  {
    id:'genshin-impact',title:'Genshin Impact',model:'freemium',genres:['Рольова гра','Пригоди'],platforms:['Windows'],developer:'HoYoverse',
    description:'Подорожуй світом Тейвату, досліджуй нові місцевості та поєднуй стихії в бою. Пригодницька рольова гра з відкритим світом.',
    details:'Збирай команду персонажів, проходь сюжетні завдання й досліджуй навколишній світ. Комбінації стихій дають змогу змінювати підхід до бою.',
    payment:'Основна гра безкоштовна. Є платна валюта та механіка отримання випадкових предметів і персонажів.',
    source:'https://genshin.hoyoverse.com/',store:'https://store.epicgames.com/p/genshin-impact',storeName:'Epic Games Store',modes:'Один гравець, кооператив',featured:true
  },
  {
    id:'fortnite',title:'Fortnite',model:'freemium',genres:['Екшен','Шутер'],platforms:['Windows'],developer:'Epic Games',
    description:'Змагайся в королівській битві, грай із друзями та відкривай світи спільноти. Обирай режим під свій настрій.',
    details:'Серед режимів є Battle Royale та Zero Build. У грі також доступні різні творчі й командні формати. Доступність окремих режимів залежить від поточної версії.',
    payment:'Безкоштовний доступ до основних режимів. Косметика, бойові перепустки та окремі пропозиції оплачуються додатково.',
    source:'https://www.fortnite.com/',store:'https://store.epicgames.com/p/fortnite',storeName:'Epic Games Store',modes:'Мережеві матчі, командна гра',featured:true
  },
  {
    id:'fall-guys',title:'Fall Guys',model:'freemium',genres:['Аркада','Платформер'],platforms:['Windows'],developer:'Mediatonic',
    description:'Смуги перешкод, кумедні падіння та боротьба за фініш. Яскрава змагальна гра, до якої легко приєднатися з друзями.',
    details:'Проходь випробування на спритність, уникай перешкод і намагайся залишитися в грі до останнього раунду. Тут важливі вчасний стрибок і трохи везіння.',
    payment:'Основна гра безкоштовна. У магазині є платні костюми, валюта та інші косметичні пропозиції.',
    source:'https://www.fallguys.com/',store:'https://store.epicgames.com/p/fall-guys',storeName:'Epic Games Store',modes:'Мережеві матчі',featured:true
  },
  {
    id:'brawlhalla',title:'Brawlhalla',model:'freemium',genres:['Файтинг','Платформер'],platforms:['Windows','macOS'],developer:'Blue Mammoth Games',
    description:'Платформний файтинг, у якому потрібно вибити суперника за межі арени. Обирай бійця й випробовуй різну зброю.',
    details:'Грай у локальних або мережевих матчах. Кожен тип зброї має свій набір прийомів, а переміщення між платформами є частиною тактики.',
    payment:'Основна гра безкоштовна. Є платні косметичні предмети й набори персонажів.',
    source:'https://www.brawlhalla.com/',store:'https://store.steampowered.com/app/291550/Brawlhalla/',storeName:'Steam',modes:'Локальні та мережеві матчі'
  },
  {
    id:'supertuxkart',title:'SuperTuxKart',model:'free',genres:['Перегони','Аркада'],platforms:['Windows','macOS','Linux'],developer:'SuperTuxKart Team',
    description:'Аркадні перегони на картах із незвичайними трасами та героями. Змагайся з комп’ютером або запроси друзів.',
    details:'Гра робить ставку на веселу аркадну фізику, різноманітні траси та предмети, які допомагають на дистанції. Проєкт розвиває спільнота.',
    payment:'Безкоштовна гра з відкритим кодом. Для завантаження не потрібно купувати базову версію.',
    source:'https://supertuxkart.net/Main_Page.html',store:'https://supertuxkart.net/Download.html',storeName:'сайті розробника',modes:'Один гравець, локальні та мережеві перегони'
  },
  {
    id:'wesnoth',title:'The Battle for Wesnoth',model:'free',genres:['Стратегія'],platforms:['Windows','macOS','Linux'],developer:'The Battle for Wesnoth Project',
    description:'Покрокова стратегія у фентезійному світі. Керуй військом, враховуй місцевість і плануй наступний хід.',
    details:'Сюжетні кампанії та мережеві битви відбуваються на картах із шестикутними клітинками. Досвід бійців і вдалий вибір позиції впливають на результат бою.',
    payment:'Безкоштовна гра з відкритим кодом. Базова версія доступна без оплати.',
    source:'https://store.steampowered.com/app/599390/Battle_for_Wesnoth/',store:'https://store.steampowered.com/app/599390/Battle_for_Wesnoth/',storeName:'Steam',modes:'Один гравець, мережеві матчі'
  },
  {
    id:'zero-ad',title:'0 A.D.',model:'free',genres:['Стратегія'],platforms:['Windows','macOS','Linux'],developer:'Wildfire Games',
    description:'Стратегія про цивілізації стародавнього світу. Збирай ресурси, будуй поселення та керуй військом у реальному часі.',
    details:'Історичні народи мають свої будівлі й підрозділи. Розвиток економіки та розташування війська допомагають підготуватися до зіткнення із суперником.',
    payment:'Безкоштовний проєкт із відкритим кодом. Розробка підтримується спільнотою.',
    source:'https://play0ad.com/',store:'https://play0ad.com/download/',storeName:'сайті розробника',modes:'Один гравець, мережеві матчі'
  },
  {
    id:'openttd',title:'OpenTTD',model:'free',genres:['Стратегія','Симулятор'],platforms:['Windows','macOS','Linux'],developer:'OpenTTD Team',
    description:'Побудуй транспортну мережу: від перших автобусних маршрутів до залізничних вузлів, портів та аеропортів.',
    details:'Перевозь пасажирів і вантажі між містами та підприємствами. Планування маршрутів, пропускна здатність і витрати на транспорт визначають розвиток компанії.',
    payment:'Безкоштовна гра з відкритим кодом. Базове завантаження не потребує покупки.',
    source:'https://www.openttd.org/',store:'https://store.steampowered.com/app/1536610/OpenTTD/',storeName:'Steam',modes:'Один гравець, мережева гра'
  },
  {
    id:'xonotic',title:'Xonotic',model:'free',genres:['Екшен','Шутер'],platforms:['Windows','macOS','Linux'],developer:'Xonotic Team',
    description:'Швидкий арена-шутер із різною зброєю та акцентом на рух. Для тих, кому подобаються короткі динамічні сутички.',
    details:'Вивчай арени, контролюй появу предметів і вдосконалюй переміщення. Можна тренуватися з ботами або приєднуватися до мережевих матчів.',
    payment:'Безкоштовна гра з відкритим кодом під ліцензією GPLv3+.',
    source:'https://xonotic.org/',store:'https://xonotic.org/download/',storeName:'сайті розробника',modes:'Гра з ботами, мережеві матчі'
  },
  {
    id:'endless-sky',title:'Endless Sky',model:'free',genres:['Симулятор','Пригоди'],platforms:['Windows','macOS','Linux'],developer:'Endless Sky contributors',
    description:'Космічна торгівля, польоти та бої у двовимірній галактиці. Почни з невеликого корабля й сам обирай напрям подорожі.',
    details:'Виконуй місії, перевозь вантажі та пасажирів, оновлюй корабель і досліджуй зоряні системи. Можна зосередитися на торгівлі або взяти участь у конфліктах.',
    payment:'Безкоштовна гра з відкритим кодом. Завантаження доступне без оплати.',
    source:'https://endless-sky.github.io/',store:'https://store.steampowered.com/app/404410/Endless_Sky/',storeName:'Steam',modes:'Один гравець'
  }
];
