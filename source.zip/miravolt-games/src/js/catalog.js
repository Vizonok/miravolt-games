export function filterGames(games, options = {}) {
  const query = (options.query || '').trim().toLocaleLowerCase('uk');
  const words = query.split(/\s+/).filter(Boolean);
  const saved = new Set(options.saved || []);
  const result = games.filter(game => {
    const searchable = [game.title, ...game.genres, ...(game.platforms || []), game.description || ''].join(' ').toLocaleLowerCase('uk');
    return words.every(word => searchable.includes(word))
      && (!options.genre || game.genres.includes(options.genre))
      && (!options.model || game.model === options.model)
      && (!options.savedOnly || saved.has(game.id));
  });
  if (options.sort === 'title') result.sort((a,b) => a.title.localeCompare(b.title,'uk',{numeric:true}));
  if (options.sort === 'title-desc') result.sort((a,b) => b.title.localeCompare(a.title,'uk',{numeric:true}));
  return result;
}

export function readSaved(raw, games) {
  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    const known = new Set(games.map(game => game.id));
    return [...new Set(parsed.filter(id => typeof id === 'string' && known.has(id)))];
  } catch {
    return [];
  }
}

export function toggleSaved(saved, id) {
  return saved.includes(id) ? saved.filter(value => value !== id) : [...saved, id];
}
