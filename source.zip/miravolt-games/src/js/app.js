import {games} from './games.js';
import {filterGames,readSaved,toggleSaved} from './catalog.js';

const storageKey='miravolt-games:saved:v1';
const prefix=document.body.dataset.prefix;
const savedOnly=document.body.dataset.savedOnly==='true';
let saved=[];
let persistent=true;
let toastTimer;
try { saved=readSaved(localStorage.getItem(storageKey),games); } catch { persistent=false; }

function announce(message) {
  const toast=document.querySelector('#toast');
  toast.textContent=message;
  toast.classList.add('visible');
  clearTimeout(toastTimer);
  toastTimer=setTimeout(()=>toast.classList.remove('visible'),4200);
}

function updateSaveButtons() {
  document.querySelectorAll('[data-saved-count]').forEach(el=>el.textContent=saved.length);
  document.querySelectorAll('[data-save]').forEach(button=>{
    const game=games.find(g=>g.id===button.dataset.save);
    const active=saved.includes(game.id);
    button.setAttribute('aria-pressed',String(active));
    button.setAttribute('aria-label',`${active?'Вилучити':'Зберегти'} ${game.title}${active?' з добірки':''}`);
    button.querySelector('.save-label').textContent=active?'У твоїй добірці':'Зберегти гру';
  });
}

document.addEventListener('click',event=>{
  const button=event.target.closest('[data-save]');
  if(!button) return;
  const id=button.dataset.save;
  saved=toggleSaved(saved,id);
  try { localStorage.setItem(storageKey,JSON.stringify(saved)); } catch { persistent=false; }
  updateSaveButtons();
  const active=saved.includes(id);
  announce(persistent?(active?'Гру додано до добірки':'Гру вилучено з добірки'):'Браузер блокує сховище. Добірка збережеться лише до оновлення сторінки.');
  if(savedOnly&&renderCatalog) {
    const cards=[...document.querySelectorAll('.game-card:not([hidden])')];
    const current=cards.findIndex(card=>card.contains(button));
    renderCatalog();
    const remaining=[...document.querySelectorAll('.game-card:not([hidden]) [data-save]')];
    (remaining[Math.min(current,remaining.length-1)]||document.querySelector(saved.length?'#reset-filters':'#browse-link')).focus();
  }
});
window.addEventListener('storage',event=>{
  if(event.key!==storageKey&&event.key!==null) return;
  saved=readSaved(event.newValue,games);
  updateSaveButtons();
  if(renderCatalog) renderCatalog();
});

let renderCatalog=null;
const grid=document.querySelector('#game-grid');
const search=document.querySelector('#search');
const form=document.querySelector('.search-form');

if(grid) {
  const params=new URLSearchParams(location.search);
  const state={model:document.body.dataset.model||'',genre:'',query:params.get('q')||'',sort:'featured'};
  if(search) search.value=state.query;
  const cards=new Map([...grid.querySelectorAll('[data-game]')].map(card=>[card.dataset.game,card]));
  renderCatalog=()=>{
    const matches=filterGames(games,{...state,saved,savedOnly});
    const ids=new Set(matches.map(g=>g.id));
    cards.forEach((card,id)=>card.hidden=!ids.has(id));
    matches.forEach(game=>grid.append(cards.get(game.id)));
    document.querySelector('#result-count').textContent=`Знайдено: ${matches.length}`;
    document.querySelectorAll('[data-model-filter]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.modelFilter===state.model)));
    const empty=document.querySelector('#empty-state');
    const emptySaved=savedOnly&&!saved.length;
    empty.hidden=matches.length>0;
    document.querySelector('#empty-title').textContent=emptySaved?'Тут будуть твої ігри':'Нічого не знайшлося';
    document.querySelector('#empty-description').textContent=emptySaved?'Натисни на закладку біля гри, яка зацікавила. Вона з’явиться тут.':'Спробуй іншу назву або прибери частину фільтрів.';
    document.querySelector('#reset-filters').hidden=emptySaved;
    document.querySelector('#browse-link').hidden=!emptySaved;
  };
  search?.addEventListener('input',()=>{state.query=search.value;renderCatalog();});
  form?.addEventListener('submit',event=>{event.preventDefault();document.querySelector('#catalog').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});});
  document.querySelector('#genre').addEventListener('change',event=>{state.genre=event.target.value;renderCatalog();});
  document.querySelector('#sort').addEventListener('change',event=>{state.sort=event.target.value;renderCatalog();});
  document.querySelectorAll('[data-model-filter]').forEach(button=>button.addEventListener('click',()=>{state.model=button.dataset.modelFilter;renderCatalog();}));
  document.querySelector('#reset-filters').addEventListener('click',()=>{
    Object.assign(state,{model:'',genre:'',query:'',sort:'featured'});
    search.value='';
    document.querySelector('#genre').value='';
    document.querySelector('#sort').value='featured';
    renderCatalog();
    search.focus();
  });
  renderCatalog();
  if(state.query) document.querySelector('#catalog').scrollIntoView();
}

const slides=[...document.querySelectorAll('[data-slide]')];
const selectors=[...document.querySelectorAll('[data-select-slide]')];
let currentSlide=0;
function showSlide(index) {
  currentSlide=(index+slides.length)%slides.length;
  slides.forEach((slide,i)=>slide.hidden=i!==currentSlide);
  selectors.forEach((button,i)=>button.setAttribute('aria-pressed',String(i===currentSlide)));
  document.querySelector('#slide-position').firstChild.textContent=`${String(currentSlide+1).padStart(2,'0')} `;
}
selectors.forEach((button,i)=>{
  button.addEventListener('click',()=>showSlide(i));
  button.addEventListener('keydown',event=>{
    if(!['ArrowDown','ArrowRight','ArrowUp','ArrowLeft','Home','End'].includes(event.key))return;
    event.preventDefault();
    const next=event.key==='Home'?0:event.key==='End'?slides.length-1:currentSlide+(['ArrowDown','ArrowRight'].includes(event.key)?1:-1);
    showSlide(next);
    selectors[currentSlide].focus();
  });
});
document.querySelectorAll('[data-slide-direction]').forEach(button=>button.addEventListener('click',()=>showSlide(currentSlide+Number(button.dataset.slideDirection))));
updateSaveButtons();
